# Final evaluation: final-20261003

Code version `6062ee03ef02`, 338 documents, 7774 results, answer keys: heldout: audited, formats: hand-written. Ollama 0.35.1. macOS 27.0.1, 18 cores.

Each model alone (with the fixed rules). Recall: how much of what should be removed was removed. Precision: how much of what was removed should have been. Full detail, the GLiNER variants and every document are in the results explorer.

| Setup | Documents | Recall (95% range) | Precision (95% range) | F1 | Missed | Over-redactions | Seconds per document |
|---|---:|---:|---:|---:|---:|---:|---:|
| rules only (no model) | 338 | 30.3% (28.3–32.3) | 98.1% (96.6–98.9) | 46.3% | 1420 | 12 | 0.0 |
| rules + GLiNER (no model) | 338 | 87.4% (85.9–88.8) | 61.0% (59.3–62.7) | 71.8% | 257 | 1180 | 0.0 |
| GLiNER only (no model) | 338 | 82.2% (80.5–83.8) | 59.6% (57.8–61.4) | 69.1% | 362 | 1182 | 0.0 |
| gemma4:31b | 337 (1 failed) | 98.2% (97.5–98.7) | 91.9% (90.7–93.0) | 94.9% | 37 | 175 | 10.7 |
| gemma4:e4b | 336 (2 failed) | 88.9% (87.5–90.2) | 77.2% (75.4–78.9) | 82.7% | 222 | 514 | 2.4 |
| gpt-oss | 338 | 95.1% (94.1–95.9) | 89.0% (87.6–90.3) | 92.0% | 100 | 235 | 6.7 |
| phi4 | 335 (3 failed) | 94.8% (93.8–95.7) | 77.6% (75.9–79.2) | 85.3% | 105 | 542 | 7.6 |
| qwen3.6:27b | 338 | 98.3% (97.6–98.8) | 82.9% (81.3–84.3) | 89.9% | 35 | 411 | 12.0 |
