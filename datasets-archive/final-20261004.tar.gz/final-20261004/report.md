# Final evaluation: final-20261004

Code version `d20d28c02c42`, 750 documents, 17250 results, answer keys: external-gretel: audited, external-nemotron: audited, heldout: audited, formats: hand-written. Ollama 0.35.1. macOS 27.0.1, 18 cores.

Each model alone (with the fixed rules). Recall: how much of what should be removed was removed. Precision: how much of what was removed should have been. Full detail, the GLiNER variants and every document are in the results explorer.

| Setup | Documents | Recall (95% range) | Precision (95% range) | F1 | Missed | Over-redactions | Seconds per document |
|---|---:|---:|---:|---:|---:|---:|---:|
| rules only (no model) | 750 | 24.3% (23.0–25.6) | 90.5% (88.6–92.1) | 38.3% | 3016 | 100 | 0.0 |
| rules + GLiNER (no model) | 750 | 82.3% (81.1–83.5) | 59.1% (57.8–60.3) | 68.8% | 704 | 2307 | 0.0 |
| GLiNER only (no model) | 750 | 78.6% (77.3–79.8) | 58.5% (57.2–59.8) | 67.1% | 853 | 2261 | 0.0 |
| gemma4:31b | 749 (1 failed) | 97.7% (97.2–98.2) | 86.5% (85.4–87.4) | 91.7% | 90 | 593 | 9.5 |
| gemma4:e4b | 748 (2 failed) | 89.5% (88.5–90.4) | 73.7% (72.5–75.0) | 80.9% | 415 | 1208 | 2.3 |
| gpt-oss | 750 | 94.6% (93.8–95.2) | 84.7% (83.6–85.7) | 89.4% | 217 | 657 | 6.3 |
| phi4 | 747 (3 failed) | 94.4% (93.6–95.0) | 74.2% (73.0–75.4) | 83.1% | 224 | 1252 | 6.8 |
| qwen3.6:27b | 749 (1 failed) | 98.0% (97.5–98.4) | 77.0% (75.8–78.2) | 86.3% | 79 | 1125 | 10.4 |
